package com.safaa.accounting;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout content, nav; TextView title;
    int blue=Color.rgb(30,58,138), green=Color.rgb(16,185,129), red=Color.rgb(239,68,68);
    @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
        db=new DB(this); content=findViewById(R.id.content); nav=findViewById(R.id.nav); title=findViewById(R.id.title); buildNav(); home();}
    TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.DKGRAY);t.setPadding(10,12,10,12);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);return b;}
    EditText ed(String hint){EditText e=new EditText(this);e.setHint(hint);e.setPadding(12,8,12,8);return e;}
    void buildNav(){String[] a={"الرئيسية","العملاء","الفروع","فاتورة بيع","سند تحصيل","كشف حساب","الإعدادات"};
        for(String s:a){Button b=btn(s);nav.addView(b); if(s.equals("الرئيسية"))b.setOnClickListener(v->home());
        else if(s.equals("العملاء"))b.setOnClickListener(v->customers()); else if(s.equals("الفروع"))b.setOnClickListener(v->branches());
        else if(s.equals("فاتورة بيع"))b.setOnClickListener(v->invoice()); else if(s.equals("سند تحصيل"))b.setOnClickListener(v->receipt());
        else if(s.equals("كشف حساب"))b.setOnClickListener(v->statement()); else b.setOnClickListener(v->settings());}}
    void base(String h){content.removeAllViews(); title.setText(h); content.addView(tv(h,20));}
    void home(){base("الرئيسية");
        content.addView(tv("نظام محاسبي محلي يعمل على الجهاز",16));
        content.addView(tv("لا يحتاج إلى استضافة أو موقع. البيانات محفوظة داخل قاعدة بيانات التطبيق.",14));
        TextView stats=tv("",16);content.addView(stats);
        Cursor c=db.raw("SELECT COUNT(*) FROM customers"); c.moveToFirst(); long customers=c.getLong(0);c.close();
        c=db.raw("SELECT COUNT(*) FROM branches");c.moveToFirst();long branches=c.getLong(0);c.close();
        c=db.raw("SELECT COUNT(*) FROM invoices");c.moveToFirst();long inv=c.getLong(0);c.close();
        c=db.raw("SELECT COUNT(*) FROM receipts");c.moveToFirst();long rec=c.getLong(0);c.close();
        stats.setText("العملاء: "+customers+"   |   الفروع: "+branches+"\\nالفواتير: "+inv+"   |   سندات التحصيل: "+rec);
    }
    void customers(){base("فتح حساب عميل"); EditText name=ed("اسم المنشأة / الصيدلية / المحل"),gov=ed("المحافظة"),district=ed("المديرية"),area=ed("المنطقة / الحي"),near=ed("أقرب معلم"),phone=ed("هاتف المنشأة"),owner=ed("اسم المالك"),ownerPhone=ed("هاتف المالك"),resp=ed("المسؤول المباشر"),respPhone=ed("هاتف المسؤول"),role=ed("صفة المسؤول");
        for(EditText e:new EditText[]{name,gov,district,area,near,phone,owner,ownerPhone,resp,respPhone,role})content.addView(e);
        Button save=btn("حفظ حساب العميل");content.addView(save);save.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()){toast("أدخل اسم المنشأة");return;}
            db.exec("INSERT INTO customers(name,gov,district,area,nearby,phone,owner,owner_phone,responsible,responsible_phone,role) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            name.getText(),gov.getText(),district.getText(),area.getText(),near.getText(),phone.getText(),owner.getText(),ownerPhone.getText(),resp.getText(),respPhone.getText(),role.getText());toast("تم حفظ العميل");});
        content.addView(btn("عرض العملاء المحفوظين")); content.getChildAt(content.getChildCount()-1).setOnClickListener(v->customerList());
    }
    void customerList(){base("العملاء"); Cursor c=db.raw("SELECT id,name,phone,district FROM customers ORDER BY name"); while(c.moveToNext())content.addView(tv(c.getInt(0)+" - "+c.getString(1)+"\\n"+c.getString(2)+" | "+c.getString(3),15));c.close();}
    void branches(){base("فتح حساب فرع"); EditText name=ed("اسم الفرع"),loc=ed("موقع الفرع"),rep=ed("اسم المندوب العلمي"),repPhone=ed("هاتف المندوب"),commission=ed("نسبة المندوب %"),salary=ed("الراتب الأسبوعي للمندوب");
        for(EditText e:new EditText[]{name,loc,rep,repPhone,commission,salary})content.addView(e);Button save=btn("حفظ الفرع");content.addView(save);
        save.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()){toast("أدخل اسم الفرع");return;}db.exec("INSERT INTO branches(name,location,rep,rep_phone,commission,salary) VALUES(?,?,?,?,?,?)",name.getText(),loc.getText(),rep.getText(),repPhone.getText(),commission.getText(),salary.getText());toast("تم حفظ الفرع");});
        Button list=btn("عرض الفروع والمصاريف");content.addView(list);list.setOnClickListener(v->branchList());
    }
    void branchList(){base("الفروع");Cursor c=db.raw("SELECT id,name,location,rep,commission,salary FROM branches ORDER BY name");while(c.moveToNext())content.addView(tv("فرع: "+c.getString(1)+"\\nالموقع: "+c.getString(2)+"\\nالمندوب: "+c.getString(3)+" | العمولة: "+c.getString(4)+"% | الراتب الأسبوعي: "+c.getString(5),15));c.close();
        content.addView(tv("يمكن إضافة مصاريف الفرع من شاشة كشف الفرع في الإصدار التالي.",14));}
    ArrayList<String> customerNames(){ArrayList<String>a=new ArrayList<>();Cursor c=db.raw("SELECT name FROM customers ORDER BY name");while(c.moveToNext())a.add(c.getString(0));c.close();return a;}
    void invoice(){base("فاتورة بيع"); EditText no=ed("رقم الفاتورة"),date=ed("التاريخ (YYYY-MM-DD)"),customer=ed("العميل"),branch=ed("الفرع / المندوب"),type=ed("نوع البيع: آجل أو نقدي"),item=ed("اسم الصنف"),batch=ed("رقم التشغيلة"),expiry=ed("تاريخ الانتهاء"),qty=ed("الكمية"),price=ed("السعر");
        date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));for(EditText e:new EditText[]{no,date,customer,branch,type,item,batch,expiry,qty,price})content.addView(e);
        Button add=btn("إضافة وحفظ الفاتورة");content.addView(add);add.setOnClickListener(v->{try{double q=Double.parseDouble(qty.getText().toString()),p=Double.parseDouble(price.getText().toString());double total=q*p;
            db.exec("INSERT INTO invoices(no,date,customer,branch,type,item,batch,expiry,qty,price,total) VALUES(?,?,?,?,?,?,?,?,?,?,?)",no.getText(),date.getText(),customer.getText(),branch.getText(),type.getText(),item.getText(),batch.getText(),expiry.getText(),q,p,total);toast("تم حفظ الفاتورة - الإجمالي "+fmt(total));}catch(Exception e){toast("تحقق من الكمية والسعر");}});
    }
    void receipt(){base("سند تحصيل");EditText no=ed("رقم السند"),date=ed("التاريخ"),customer=ed("العميل"),rep=ed("المندوب المستلم"),amount=ed("المبلغ"),notes=ed("ملاحظات");
        date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));notes.setText("دفعة أسبوعية");for(EditText e:new EditText[]{no,date,customer,rep,amount,notes})content.addView(e);
        Button save=btn("حفظ سند التحصيل");content.addView(save);save.setOnClickListener(v->{try{double a=Double.parseDouble(amount.getText().toString());db.exec("INSERT INTO receipts(no,date,customer,rep,amount,notes) VALUES(?,?,?,?,?,?)",no.getText(),date.getText(),customer.getText(),rep.getText(),a,notes.getText());toast("تم حفظ السند");}catch(Exception e){toast("أدخل مبلغاً صحيحاً");}});
    }
    void statement(){base("كشف حساب");EditText customer=ed("اسم العميل (اتركه فارغاً لإظهار الكل)");content.addView(customer);Button show=btn("إظهار الكشف");content.addView(show);
        show.setOnClickListener(v->{String n=customer.getText().toString().trim();Cursor i=n.isEmpty()?db.raw("SELECT date,no,customer,total FROM invoices ORDER BY date"):db.raw("SELECT date,no,customer,total FROM invoices WHERE customer=? ORDER BY date",n);
            double bal=0;StringBuilder s=new StringBuilder("التاريخ | البيان | مدين | دائن | الرصيد\\n\\n");while(i.moveToNext()){double x=i.getDouble(3);bal+=x;s.append(i.getString(0)).append(" | فاتورة ").append(i.getString(1)).append(" | ").append(fmt(x)).append(" | 0 | ").append(fmt(bal)).append("\\n");}i.close();
            Cursor r=n.isEmpty()?db.raw("SELECT date,no,customer,amount FROM receipts ORDER BY date"):db.raw("SELECT date,no,customer,amount FROM receipts WHERE customer=? ORDER BY date",n);
            while(r.moveToNext()){double x=r.getDouble(3);bal-=x;s.append(r.getString(0)).append(" | سند ").append(r.getString(1)).append(" | 0 | ").append(fmt(x)).append(" | ").append(fmt(bal)).append("\\n");}r.close();content.addView(tv(s.toString(),13));content.addView(tv("الرصيد النهائي: "+fmt(bal),18));});
    }
    void settings(){base("الإعدادات");EditText name=ed("اسم الشركة"),address=ed("العنوان"),phone=ed("الهاتف");name.setText("صفاء هربل لمستحضرات التجميل");address.setText("صنعاء");phone.setText("770000000");for(EditText e:new EditText[]{name,address,phone})content.addView(e);
        Button save=btn("حفظ إعدادات الشركة");content.addView(save);save.setOnClickListener(v->{getPreferences(0).edit().putString("name",name.getText().toString()).putString("address",address.getText().toString()).putString("phone",phone.getText().toString()).apply();toast("تم حفظ الإعدادات");});
        Button backup=btn("نسخ احتياطي لقاعدة البيانات");content.addView(backup);backup.setOnClickListener(v->backup());
        Button clear=btn("حذف جميع البيانات");content.addView(clear);clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("تأكيد").setMessage("سيتم حذف العملاء والفروع والفواتير والسندات نهائياً من التطبيق.").setPositiveButton("حذف", (d,w)->{db.clear();toast("تم حذف البيانات");}).setNegativeButton("إلغاء",null).show());
    }
    void backup(){try{File dbfile=getDatabasePath("safaa.db");File out=new File(getExternalFilesDir(null),"safaa_backup_"+System.currentTimeMillis()+".db");FileInputStream in=new FileInputStream(dbfile);FileOutputStream o=new FileOutputStream(out);byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);in.close();o.close();toast("تم إنشاء النسخة الاحتياطية داخل مجلد ملفات التطبيق");}catch(Exception e){toast("تعذر إنشاء النسخة");}}
    String fmt(double x){return String.format(Locale.US,"%,.2f",x);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    public static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"safaa.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,gov TEXT,district TEXT,area TEXT,nearby TEXT,phone TEXT,owner TEXT,owner_phone TEXT,responsible TEXT,responsible_phone TEXT,role TEXT)");
            d.execSQL("CREATE TABLE branches(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,location TEXT,rep TEXT,rep_phone TEXT,commission TEXT,salary TEXT)");
            d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,no TEXT,date TEXT,customer TEXT,branch TEXT,type TEXT,item TEXT,batch TEXT,expiry TEXT,qty REAL,price REAL,total REAL)");
            d.execSQL("CREATE TABLE receipts(id INTEGER PRIMARY KEY AUTOINCREMENT,no TEXT,date TEXT,customer TEXT,rep TEXT,amount REAL,notes TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        Cursor raw(String q,String...args){return getReadableDatabase().rawQuery(q,args);}
        void exec(String q,Object...v){SQLiteStatement s=getWritableDatabase().compileStatement(q);for(int i=0;i<v.length;i++){Object x=v[i];if(x==null)s.bindNull(i+1);else if(x instanceof Number)s.bindDouble(i+1,((Number)x).doubleValue());else s.bindString(i+1,x.toString());}s.executeInsert();s.close();}
        void clear(){getWritableDatabase().execSQL("DELETE FROM customers");getWritableDatabase().execSQL("DELETE FROM branches");getWritableDatabase().execSQL("DELETE FROM invoices");getWritableDatabase().execSQL("DELETE FROM receipts");}
    }
}